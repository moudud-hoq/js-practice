/***

Implement a countdown timer that counts down from 21 to 15.

 */


/*programming hero*/