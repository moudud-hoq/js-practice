/*
display odd number from 55 to 85 and skip the numbers divisible by 5.
*/