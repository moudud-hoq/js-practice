/* 
Write a loop to print even numbers from 1 to 40. Use continue to skip odd numbers.
*/