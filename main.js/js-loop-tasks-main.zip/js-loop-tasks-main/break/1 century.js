/* 

Write a loop 1 to 200. Use break to exit the loop once you find 100.

*/