/***

Generate a multiplication table for number 9

 */


/*programming hero*/