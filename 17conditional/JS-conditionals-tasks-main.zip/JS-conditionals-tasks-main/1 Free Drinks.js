/***

Free Drinks
    - Burger more than 500tk: free Coke
    - Else Coke: 30tk
*/
